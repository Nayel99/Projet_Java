package Graphic;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.*;

import projet_long_virus.Virus;

public class InterfaceImportVirus extends JFrame {

	private static final long serialVersionUID = 1L;
	
	private Virus virus_Utilisateur;
	
	private JTextArea text = new JTextArea("");
	
	private Virus virus_faible = new Virus(3, 1, 2, 0);
	
	private Virus virus_normal = new Virus(5, 2, 4, 0.2);
	
	private Virus virus_dangeureux = new Virus(10, 7, 9, 0.7);
	
	private JComboBox<String> ImportVirus;
	
	private JLabel textImportVirus = new JLabel("Veullez choisur le virus");
	
	private JTextArea textVirusfaible;
	
	private JTextArea textVirusNormal;
	
	private JTextArea textVirusDangereux;
	
	private Choix actionChoix = new Choix();
	
	private  JButton BouttonOk = new JButton("Ok");
	
	private final ActionListener actionOK = new actionOK();
	
	private  JButton BouttonAnnuler = new JButton("Annuler");
	
	private final ActionListener actionAnnuler = new actionAnnuler();
	
	public InterfaceImportVirus() {
		super( "Importer le virus" );
		
		InitialiserFenetre();
		AjouterListener();
		InitialiserTextVirus();
		EditerChoix();
		this.add(AjouterTous(),BorderLayout.NORTH);
		this.add(text,BorderLayout.CENTER);
		this.add(sud(),BorderLayout.SOUTH);
	}
	
	private JPanel AjouterTous() {
		JPanel d = new JPanel(new FlowLayout());
		d.add(textImportVirus);
		d.add(ImportVirus);
		return d;
	}
	
	private void InitialiserFenetre() {
		this.setDefaultCloseOperation( JFrame.DISPOSE_ON_CLOSE );
		this.setSize( 400, 300 );																			
		this.setLocationRelativeTo( null ); 
		this.setLayout( new BorderLayout() );
        
	}
	
	private void AjouterListener() {
		this.BouttonOk.addActionListener(this.actionOK);
		this.BouttonAnnuler.addActionListener(this.actionAnnuler);
	}
	
	private void InitialiserTextVirus() {
		textVirusfaible = new JTextArea("Ce virus n'est pas dangeureux.\n" 
				+ "Il ne tue pas et la contamination est faible " );
		textVirusNormal = new JTextArea("Ce virus n'est pas tres dangeureux.\n"
				+ "Le taux de mortalite est faible mais il se propage un peu facilement" );
		textVirusDangereux = new JTextArea("Ce virus est dangeureux.\n"
				+ "Le taux de mortalite est eleve il se propage facilement" );
	}
	
	private void EditerChoix() {
		this.textImportVirus.setFont(new Font("Arial",Font.BOLD,14));
		this.textImportVirus.setOpaque(false);
		String[] typeVirus= { "Virus faible", "Virus Normal", "Virus Dangereux"};
		this.ImportVirus = new JComboBox<String>(typeVirus);
		this.ImportVirus.addActionListener(actionChoix);
	}	
	
	private JPanel sud() {
		JPanel dialogue = new JPanel(new FlowLayout());
		dialogue.setLayout(new FlowLayout(FlowLayout.CENTER, 10,10 ));
		dialogue.add(BouttonOk);
		BouttonOk.setPreferredSize(new Dimension(100,30));
		dialogue.add(BouttonAnnuler);
		BouttonAnnuler.setPreferredSize(new Dimension(100,30));
		return dialogue;
	}
	
	private void TextChois(JTextArea textchoisi) {
		text.setText(textchoisi.getText());
		
	}
	
	public void VirusChoisi(Virus viruschois) {
		virus_Utilisateur = viruschois;
	}
	
	public class Choix implements ActionListener{
	    public void actionPerformed(ActionEvent e) {

	    	String option = (String) ImportVirus.getSelectedItem();
	    	switch (option) {
				case "Virus faible": {
					TextChois(textVirusfaible);
					VirusChoisi(virus_faible);
					break;
				}
				case "Virus Normal": {
					TextChois(textVirusNormal);
					VirusChoisi(virus_normal);
					break;
				}
				case "Virus Dangereux": {
					TextChois(textVirusDangereux);
					VirusChoisi(virus_dangeureux);
					break;
				}
			}
	      }               
	  }
	
	public class actionOK implements ActionListener {
		public void actionPerformed(ActionEvent e) {	
			InterfaceSimulation.InitialiserVirus(virus_Utilisateur);
			InterfacePrincipale.VirusExiste(true);
			InterfacePrincipale.Simulasionpossible();
			dispose();
		}
	}
	
	public class actionAnnuler implements ActionListener {
		public void actionPerformed(ActionEvent e) {
			dispose();
		}
	}
	
}
